# ZWH_Sparest-input-selection-for-descriptor-systems
Codes for sparsest input selection for singular systems_a two step algorithm_written by Wanghong Zhang From Qinghai University
